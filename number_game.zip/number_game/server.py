#IMPORTS
from flask import Flask, render_template, request, redirect, session
import random
#INITILIZE
app = Flask(__name__)
app.secret_key = "This is the secret key."

#ROUTES 
@app.route('/')
def index():
    # if "guess" not in session:
    #     session['guess'] = 0
    if "num" not in session:
        session['num'] = random.randint(1,26)
    return render_template('index.html')

@app.route('/guess', methods=["POST"])
def process_guess():
    session['guess'] = int(request.form['guess'])
    return redirect('/')

@app.route('/restart')
def restart():
    session.clear()
    return redirect('/')

#RUN SERVER
if __name__ == "__main__":
    app.run(debug=True)