from flask import Flask, render_template  # Import Flask to allow us to create our app
app = Flask(__name__)    # Create a new instance of the Flask class called "app"

# @app.route('/success')
# def success():
#     return "success"
# @app.route('/say/<name>') # for a route '/hello/____' anything after '/hello/' gets passed as a variable 'name'
# def hello(name):
#     print(name)
#     return "Hello, " + name
# @app.route('/repeat/<int:num>/<string:name>')
# def repeat(num, name):
#     return f"{name} "  * num

@app.route('/')          
def hello():
    return 'Hello, World!'

@app.route('/play')
def play():
    return render_template("index.html")

@app.route('/play/<int:num>')
def numplay(num):
    return render_template("numplay.html", num = num)

@app.route('/play/<int:num>/<string:col>')
def numcolplay(num, col):
    return render_template("numcolplay.html", num = num, col = col)

# @app.route('/play/<int:num>')
# def playnum(num):
#     return render_template('index.html')

if __name__=="__main__":   # Ensure this file is being run directly and not from a different module    
    app.run(debug=True)    # Run the app in debug mode.

